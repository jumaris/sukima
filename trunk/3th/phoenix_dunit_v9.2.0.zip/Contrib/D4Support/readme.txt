The \src and \tests subdirs contain D4 .dfm binaries of the .dfm files
distributed in the main \src and \tests dirs. You can overwrite the .dfms
in the main dirs with the D4 ones in order to use these with D4.

The convert.bat is a batch which will generate the latest D4 .dfms from the
D5 (or greater) .dfms in the distribution. Modify the convert.bat to set
the proper paths before you use it.

Chris Morris
DUnit co-Admin (the lesser)
May 2003